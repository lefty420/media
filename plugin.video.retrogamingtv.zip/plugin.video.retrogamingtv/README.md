<meta name=”robots” content=”noindex, nofollow”>
Retro Gaming Tv Addon for Kodi
==========================
![enter image description here](https://github.com/lefty420/plugin.video.retrotv/blob/master/fanart.jpg)

A simple addon for kodi that streams classic retro tvshows from YouTube. Watch a wide array of shows including, Super Mario bros, Sonic the hedgehogand Classic gaming shows such as Gamesmaster, Bad Infuence and Games world.

Based on code from the YouTube Addon
==========================
![enter image description here](http://www.superluigibros.com/images/super_mario_bros_super_show_releases/mario_bros_mix.jpg) 
![enter image description here](http://megagames.com/sites/default/files/game-content-images/gamesmaster.jpg)
![enter image description here](http://vignette1.wikia.nocookie.net/magazinesfromthepast/images/3/3a/Bad_Influence_Issue_1.jpg/revision/latest?cb=20141128220822)
